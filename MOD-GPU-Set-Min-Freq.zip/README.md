# Fix Radioactive Fork MOD GPU incorrect default GPU min power level and frequency
