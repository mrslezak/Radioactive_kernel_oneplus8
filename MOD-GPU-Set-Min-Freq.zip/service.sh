#!/system/bin/sh

MODDIR=${0%/*}

sleep 5
echo 295 > /sys/class/kgsl/kgsl-3d0/min_clock_mhz
echo 8 > /sys/class/kgsl/kgsl-3d0/default_pwrlevel

exit 0
